const apiBase = "https://api.open-meteo.com/v1/forecast";

document.getElementById("searchBtn").addEventListener("click", getWeather);

async function getWeather() {
    const city = document.getElementById("cityInput").value.trim();
    if (!city) {
        alert("Please enter a city name.");
        return;
    }

    try {
        // Geocoding
        const geoRes = await fetch(`https://geocoding-api.open-meteo.com/v1/search?name=${encodeURIComponent(city)}`);
        const geoData = await geoRes.json();
        if (!geoData.results || geoData.results.length === 0) {
            alert("City not found!");
            return;
        }
        const { latitude, longitude, name, country } = geoData.results[0];

        // Weather Data
        const url = `${apiBase}?latitude=${latitude}&longitude=${longitude}&current_weather=true&hourly=temperature_2m,weathercode,windspeed_10m,relative_humidity_2m,precipitation&daily=temperature_2m_max,temperature_2m_min,precipitation_sum,weathercode,windspeed_10m_max&timezone=auto`;
        const weatherRes = await fetch(url);
        const weatherData = await weatherRes.json();
        console.log(weatherData);

        // Date
        const now = new Date();
        document.getElementById("cityName").textContent = `${name}, ${country}`;
        document.getElementById("dateStr").textContent = now.toLocaleDateString(undefined, { weekday: 'long', year: 'numeric', month: 'short', day: 'numeric' });

        //"Current" Section
        if (weatherData.current_weather) {
            document.getElementById("temp").textContent = `${Math.round(weatherData.current_weather.temperature)}°`;
            document.getElementById("feelsLike").textContent = `${Math.round(weatherData.current_weather.temperature)}°`;
            document.getElementById("humidity").textContent = weatherData.hourly.relative_humidity_2m ? `${weatherData.hourly.relative_humidity_2m[0]}%` : "--%";
            document.getElementById("wind").textContent = typeof weatherData.current_weather.windspeed === "number" ? `${weatherData.current_weather.windspeed} m/s` : "-- m/s";
            document.getElementById("precip").textContent = weatherData.hourly.precipitation ? `${weatherData.hourly.precipitation[0]} mm` : "-- mm";
            document.getElementById("bigIcon").src = getWeatherIcon(weatherData.current_weather.weathercode);
            document.getElementById("bigIcon").alt = getWeatherLabel(weatherData.current_weather.weathercode);
        } else {
            document.getElementById("temp").textContent = "--°";
            document.getElementById("feelsLike").textContent = "--°";
            document.getElementById("humidity").textContent = "--%";
            document.getElementById("wind").textContent = "-- m/s";
            document.getElementById("precip").textContent = "-- mm";
            document.getElementById("bigIcon").src = "";
            document.getElementById("bigIcon").alt = "";
        }

        //"Daily Forecast"
        const dailyContainer = document.getElementById("dailyForecast");
        dailyContainer.innerHTML = "";
        if (weatherData.daily && weatherData.daily.time) {
            for (let i = 0; i < weatherData.daily.time.length; i++) {
                const date = new Date(weatherData.daily.time[i]);
                dailyContainer.innerHTML += `
                  <div class="day">
                    <div>${date.toLocaleDateString(undefined, { weekday: 'short' })}</div>
                    <img class="weather-icon" src="${getWeatherIcon(weatherData.daily.weathercode[i])}" alt="" />
                    <div>${Math.round(weatherData.daily.temperature_2m_max[i])}° / ${Math.round(weatherData.daily.temperature_2m_min[i])}°</div>
                    <div>💧${weatherData.daily.precipitation_sum[i] || 0} mm</div>
                  </div>`;
            }
        }

        //"Hourly Forecast" 
        const hourlyContainer = document.getElementById("hourlyForecast");
        hourlyContainer.innerHTML = "";
        if (weatherData.hourly && weatherData.hourly.time) {
            for (let i = 0; i < 24 && i < weatherData.hourly.time.length; i++) {
                const date = new Date(weatherData.hourly.time[i]);
                hourlyContainer.innerHTML += `
                  <div class="hour">
                    <div>${date.getHours()}:00</div>
                    <img class="weather-icon" src="${getWeatherIcon(weatherData.hourly.weathercode[i])}" alt="" />
                    <div>${Math.round(weatherData.hourly.temperature_2m[i])}°</div>
                  </div>`;
            }
        }

    } catch (err) {
        console.error(err);
        alert("Error retrieving weather data. Please try again.");
    }
}

function getWeatherIcon(code) {
    const icons = {
        0: "https://openweathermap.org/img/wn/01d.png", // Clear
        1: "https://openweathermap.org/img/wn/02d.png", // Mainly clear
        2: "https://openweathermap.org/img/wn/03d.png", // Partly cloudy
        3: "https://openweathermap.org/img/wn/04d.png", // Overcast
        45: "https://openweathermap.org/img/wn/50d.png", // Fog
        48: "https://openweathermap.org/img/wn/50d.png", // Fog
        51: "https://openweathermap.org/img/wn/09d.png", // Drizzle
        61: "https://openweathermap.org/img/wn/10d.png", // Rain
        80: "https://openweathermap.org/img/wn/09d.png", // Rain showers
        95: "https://openweathermap.org/img/wn/11d.png", // Thunderstorm
    };
  
    return icons[code] || "https://openweathermap.org/img/wn/01d.png";
}

function getWeatherLabel(code) {
    const labels = {
        0: "Clear sky",
        1: "Mostly clear",
        2: "Partly cloudy",
        3: "Overcast",
        45: "Fog",
        48: "Fog",
        51: "Light drizzle",
        61: "Light rain",
        80: "Rain showers",
        95: "Thunderstorm",
    };
    return labels[code] || "Unknown";
}











